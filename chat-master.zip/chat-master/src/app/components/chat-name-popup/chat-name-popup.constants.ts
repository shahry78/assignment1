import { IConfig } from "../../../assets/interfaces/shared.interface";

export const CONFIG: IConfig = {
  placeholder: "Enter your name",
  buttonLabel: "start chat"
};
