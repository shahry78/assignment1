# Chat Backend

    cd server
    npm i
    npm start

# Chat UI

    npm i
    npm start

Enjoy!
